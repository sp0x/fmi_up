#include "TicTacToe.cpp"

void main(){
    TicTacToe game();
    game.start();
}