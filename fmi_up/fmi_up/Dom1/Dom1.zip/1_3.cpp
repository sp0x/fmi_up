//1_3.cpp
#include <iostream>
#include <cstring>
using namespace std;


void main(){
        bool lovePrograming = true;
        bool loveLudogorets = false;
        bool programShouldHAVEComments = true;
        cout << "I love programming" << lovePrograming;
        cout << "I love Ludogorets" << loveLudogorets;
        cout << "Programs should have comments " << programShouldHAVEComments;
}
