//1_2.cpp
#include <iostream>
#include <cstring>
using namespace std;


void main(){
    int age = 59;
    cout << "Hi I'm " << age << " and my name is Gates Bill";
}

