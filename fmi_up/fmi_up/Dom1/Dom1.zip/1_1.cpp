//1_1.cpp
#include <iostream>

using namespace std;

void main(){
    cout << "Hi, FMI";
}